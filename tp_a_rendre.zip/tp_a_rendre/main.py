from TP.APP import APP

def main():
    print("Main Launching...")
    app=APP()
    
if __name__=="__main__":
    # print("test")
    main()