#################################################################################################
#                                                                                               #
#                                       DEFINITION                                              #
#                                                                                               #
#################################################################################################
import tkinter as tk
from tkinter import ttk, messagebox
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg


#################################################################################################
#                                                                                               #
#                                           CODE                                                #
#                                                                                               #
#################################################################################################

class ScreenManager:
    def __init__(self, gui):
        from TP.GUI import GUI
        self.gui : GUI = gui # Reference to the main GUI
        self.current_screen = None
        self.screens = {
            "HomeScreen": HomeScreen,
            "ReadScreen": ReadScreen,
            "ComputeScreen":ComputeScreen
        }


    def show_screen(self, screen_name:str):
        """Transition to a specific screen."""
        print(f"showing screen:{screen_name}")
        if self.current_screen:
            self.current_screen.destroy()  # Remove current screen
        screen_class = self.screens.get(screen_name)
         
        if screen_class:
            print(f"{screen_name} selected")
            self.current_screen = screen_class(self)  # Instantiate the screen class
            self.current_screen.pack()  # Pack the new screen
            print(f"Packing {self.current_screen}...")
        else:
            print(f"Screen {screen_name} not found.")

        
        
class BaseScreen(tk.Frame):
    """A base class for all screens."""
    def __init__(self, manager: ScreenManager):
        
        super().__init__(manager.gui.root)
        
        self.manager = manager
      
        
    def getScreenHeader(self, Screen_title:str):
        """Create a header for the screen."""
        self.header = tk.Frame(self)
        homeBtn = tk.Button(self.header, text="Home", command=self.goHome)
        headerTitle = tk.Label(self.header, text = Screen_title)
        homeBtn.grid(column=0, padx=10)
        headerTitle.grid(column=1, padx=10)
        if self.manager.screens.get(self.manager.current_screen) is ReadScreen :
            ComputeBtn = tk.Button(self.header, text="Home", command=lambda:self.manager.show_screen("ComputeScreen"))
            ComputeBtn.grid(column=2, padx=10)
        elif self.manager.screens.get(self.manager.current_screen) is ComputeScreen : 
            ReadBtn = tk.Button(self.header, text="Home", command=lambda:self.manager.show_screen("ReadScreen"))
            ReadBtn.grid(column=2, padx=10)
        return self.header
       
        
    def goHome(self):
        self.manager.show_screen("HomeScreen")
   
   
    def setup_widgets(self):
        raise NotImplementedError("Subclasses should implement this method.")


    def refresh_screen(self):
        print("Refreshing page...")
        for widget in self.winfo_children():  # Destroy all existing widgets
            widget.destroy()
        self.setup_widgets()
        
        
        
class HomeScreen(BaseScreen):
    def __init__(self, manager):
        super().__init__(manager)
        self.setup_widgets()
        
        
    def setup_widgets(self):
        label = tk.Label(self, text="Welcome to the Home Screen")
        label.pack(pady=10)
        
        
        data_label = tk.Label(self, text=f"Database is {self.manager.gui.dbHandler.data_status}")
        data_label.pack(pady=10)
        
        btn_reader = tk.Button(self, text="Go to data reader screen", command=lambda: self.manager.show_screen("ReadScreen"))
        btn_reader.pack(pady=10)
        
        btn_visualiser = tk.Button(self, text="Go to Computing screen", command=lambda: self.manager.show_screen("ComputeScreen"))
        btn_visualiser.pack(pady=10)

     
     
class ReadScreen(BaseScreen):
    def __init__(self, manager: ScreenManager):
        super().__init__(manager)
        self.setup_widgets()

        
    def setup_widgets(self):
        self.getScreenHeader("Data Reader").pack(pady=10)
        
        self.table_frame = tk.Frame(self)
        self.table_frame.pack(pady=10, fill="both")
                
        self.columns = self.manager.gui.dbHandler.df.columns.tolist()
        self.tree = ttk.Treeview(self.table_frame, columns=self.columns, show="headings")
        
        for col in self.columns:
            self.tree.heading(col, text =col)
            self.tree.column(col, anchor="center", width=100)
        
        self.scrollbar = ttk.Scrollbar(self.table_frame, orient="vertical", command=self.tree.yview)

        self.tree.configure(yscroll=self.scrollbar.set)
        
        
        self.tree.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        self.scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        
        self.populate_table()
        self.footer = tk.Frame(self)
        
        self.clean_btn = tk.Button(self.footer, text="clean", command=self.clean_data)
        self.clean_btn.grid(row=0,column=0, padx=15)
        
        miss_data = self.manager.gui.dbHandler.get_missing_data()
        miss_data = f"Missing :\n {miss_data}"
        self.data_missing = tk.Label(self.footer, text=miss_data)
        self.data_missing.grid(row=0,column=1, padx=15)
        
        
        abh_percent = self.manager.gui.dbHandler.get_abh_data()
        abh_percent = f"Aberrant :\n {abh_percent}"
        self.abh_per_lbl = tk.Label(self.footer, text=abh_percent)
        self.abh_per_lbl.grid(row=0,column=3, padx=15)
        
        
        self.footer.pack()
        
        
        # self.refresh_btn = tk.Button(self, text="Refresh", command=self.refresh_screen())
        
        
    def clean_data(self):
        self.manager.gui.dbHandler.clean_missing()        
        self.manager.gui.dbHandler.clean_abh()
        self.refresh_screen()      
        
        
    def populate_table(self):
        data = self.manager.gui.dbHandler.df
        for row in self.tree.get_children():
            self.tree.delete(row)
        for index, row in data.iterrows():
            self.tree.insert("", "end", values=row.tolist())
        
        
        
class ComputeScreen(BaseScreen):
    def __init__(self, manager: ScreenManager):
        super().__init__(manager)
        self.setup_widgets()
        self.pltcanvas = None
        self.displaying = "Text"
        
    def setup_widgets(self):
        self.getScreenHeader("Computing Screen").pack(pady=10)

        self.text_display = tk.Text(self, wrap="word", height=20, width=80)
        self.text_display.pack(pady=10)
        
        self.manager.gui.dbHandler.clean_abh()
        self.manager.gui.dbHandler.clean_missing()
        
        self.btn_frame = tk.Frame(self)
        
        btn_Random = tk.Button(self.btn_frame, text="Random Forrest",
                               command=self.start_random)
        btn_Random.grid(padx=15, pady=10, row=0, column=0)
        
        btn_AdaBoost = tk.Button(self.btn_frame, text="AdaBoost",
                               command=self.start_ada)
        btn_AdaBoost.grid(padx=15, pady=10, row=0, column=1)
        
        btn_SVM = tk.Button(self.btn_frame, text="SVM",
                               command=self.start_SVM)
        btn_SVM.grid(padx=15, pady=10, row=0, column=2)
        
        btn_Corr =tk.Button(self.btn_frame, text="CORRELATION MX",
                               command=self.start_Correlation_mx)
        btn_Corr.grid(padx=15, pady=10, row=1, column=0)
        
        btn_PCA =tk.Button(self.btn_frame, text="PCA",
                               command=self.start_PCA)
        btn_PCA.grid(padx=15, pady=10, row=1, column=1)
        
        btn_KM =tk.Button(self.btn_frame, text="KMEANS",
                               command=self.start_kmeans)
        btn_KM.grid(padx=15, pady=10, row=1, column=2)
        
        self.btn_frame.pack(pady=10)
        
        
    def start_random(self):
        if self.displaying == "Plot":
            self.remove_canvas()
            self.btn_frame.pack_forget()
            self.text_display.pack() 
            self.btn_frame.pack()
            self.displaying = "Text"
            
            
        self.text_display.delete("1.0", tk.END)
        Acc, classification, confusion_mx = self.manager.gui.dbHandler.Random_forrest()
        self.text_display.insert(tk.END, f"Random Forrest accuracy : {Acc}\n Classification :\n {classification}\n Matrix de confusion : \n {confusion_mx}")
        
        
    def start_ada(self):
        if self.displaying == "Plot":
            self.remove_canvas()
            self.btn_frame.pack_forget()
            self.text_display.pack() 
            self.btn_frame.pack()
            self.displaying = "Text"
        self.text_display.delete("1.0", tk.END)
        Acc, classification, confusion_mx = self.manager.gui.dbHandler.Ada_boost()
        self.text_display.insert(tk.END, f"AdaBoost accuracy : {Acc}\n Classification :\n {classification}\n Matrix de confusion : \n {confusion_mx}")


    def start_SVM(self):
        if self.displaying == "Plot":
            self.remove_canvas()
            self.btn_frame.pack_forget()
            self.text_display.pack() 
            self.btn_frame.pack()
            self.displaying = "Text"
        self.text_display.delete("1.0", tk.END)
        Acc, classification, confusion_mx = self.manager.gui.dbHandler.SVM()
        self.text_display.insert(tk.END, f"SVM accuracy : {Acc}\n Classification :\n {classification}\n Matrix de confusion : \n {confusion_mx}")


    def start_Correlation_mx(self):
           
        if self.displaying == "Text":
            self.text_display.pack_forget()  # Hide the text display
            self.displaying = "Plot"
        elif self.displaying == "Plot":
            self.remove_canvas()
        self.btn_frame.pack_forget()
        corr_mx = self.manager.gui.dbHandler.Correlation_mx()
        
        self.pltcanvas = FigureCanvasTkAgg(corr_mx, master=self)
        self.pltcanvas.draw()
        self.pltcanvas.get_tk_widget().pack(fill=tk.BOTH, expand=True)
        self.btn_frame.pack(pady=10)
        # self.text_display.insert(tk.END, f"Correlation Matrix :\n {corr_mx}")
        

    def start_PCA(self):
        if self.displaying == "Text":
            self.text_display.pack_forget()  # Hide the text display
            self.displaying = "Plot"
        elif self.displaying == "Plot":
            self.remove_canvas()
            
        self.btn_frame.pack_forget()
        PCA_fg = self.manager.gui.dbHandler.PCA()
        
        self.pltcanvas = FigureCanvasTkAgg(PCA_fg, master=self)
        self.pltcanvas.draw()
        self.pltcanvas.get_tk_widget().pack(fill=tk.BOTH, expand=True)
        self.btn_frame.pack(pady=10)


    def start_kmeans(self):
        if self.displaying == "Text":
            self.text_display.pack_forget()  # Hide the text display
            self.displaying = "Plot"
        elif self.displaying == "Plot":
            self.remove_canvas()
        self.btn_frame.pack_forget()
        KMeans_fg = self.manager.gui.dbHandler.KMeans()
        
        self.pltcanvas = FigureCanvasTkAgg(KMeans_fg, master=self)
        self.pltcanvas.draw()
        self.pltcanvas.get_tk_widget().pack(fill=tk.BOTH, expand=True)
        self.btn_frame.pack(pady=10)
        
        
        
    def remove_canvas(self):
        if self.pltcanvas is not None:
            self.pltcanvas.get_tk_widget().pack_forget()  # Hide the canvas
            self.pltcanvas = None