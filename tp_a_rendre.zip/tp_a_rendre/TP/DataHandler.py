#################################################################################################
#                                                                                               #
#                                       DEFINITION                                              #
#                                                                                               #
#################################################################################################

import os 
import tkinter as tk
import pandas as pd
import numpy as np
import seaborn as sns
from tkinter import ttk, messagebox
from sklearn.model_selection import train_test_split
from sklearn.ensemble import AdaBoostClassifier
from sklearn.tree import DecisionTreeClassifier
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score, classification_report, confusion_matrix
from sklearn.svm import SVC
from sklearn.preprocessing import StandardScaler, OneHotEncoder
from sklearn.cluster import KMeans
import matplotlib.pyplot as plt
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
from sklearn.decomposition import PCA

#################################################################################################
#                                                                                               #
#                                           CODE                                                #
#                                                                                               #
#################################################################################################

class DBHandler:
    def __init__(self) -> None:
        print("Initializing DBHandler")
        current_directory = os.path.dirname(os.path.abspath(__file__))
        print(current_directory)
        data_filename = "data/Medicaldataset.csv"
        self.filepath = os.path.join(current_directory, data_filename)
        #Can you make it so that instead of my entire folder's path it just asks for the relative of the file ?
        if os.path.exists(self.filepath):
            self.data_status = "Connected"
            self.df = pd.read_csv(self.filepath)
            self.limits = {
            'Age': (0, 120),
            'Gender': (0, 1),
            'Heart rate': (30, 200),
            'Systolic blood pressure': (50, 250),
            'Diastolic blood pressure': (30, 150),
            'Blood sugar': (20, 600),
            'CK-MB': (0, 100),
            'Troponin': (0, 100),
            'Result': ("positive", "negative")
        }
        else : 
            messagebox.showerror("Data absent",f" L'Appli ne marche pas sans sa data.\n Current path : {self.filepath}")
            self.data_status = "Disconnected"
            exit()
            
            
    def get_missing_data(self):
        return self.df.isnull().mean() *100
    
    
    def clean_abh(self):
        messagebox.showinfo("Cleaning...", "We are replacing aberrant data")
        for column, limits_range in self.limits.items():
            if column in self.df.columns:
                lower_limit, upper_limit = limits_range
                if isinstance(lower_limit, (int, float)) and isinstance(upper_limit, (int, float)):
                    aberrant_indices = self.df[(self.df[column] < lower_limit) | (self.df[column] > upper_limit)].index 
                    mean_val = self.df[column].mean()
                    if pd.api.types.is_integer_dtype(self.df[column]):
                        mean_val = int(mean_val)
                    elif pd.api.types.is_float_dtype(self.df[column]):
                        round(float(mean_val), 4)
                    
                    if pd.api.types.is_float_dtype(self.df[column]):
                        self.df[column] = self.df[column].apply(
                            lambda x: round(x, 4) 
                            if isinstance(x, float) and len(str(x).split(".")[1]) > 4
                            else x
                        )
                    
                    self.df.loc[aberrant_indices, column] = mean_val
                elif isinstance(lower_limit, str) and isinstance(upper_limit, str):
                    bool_mapping = {"positive": True, "negative": False}
                    self.df[column] = self.df[column].map(bool_mapping).fillna(self.df[column])  # Map and fill non-matching with original values
                
                    
                    aberrant_indices = self.df[~self.df[column].isin(limits_range)].index
                    
                    mode_value = self.df[column].mode().iloc[0]
                    mode_value = mode_value if isinstance(mode_value, type(self.df[column].iloc[0])) else type(self.df[column].iloc[0])(mode_value)
                    
                    self.df.loc[aberrant_indices, column] = mode_value
        messagebox.showinfo("Cleaning done", "*Aberrant data has been cleaned")  
    
    
    def clean_missing(self):
        messagebox.showinfo("Cleaning...","We are cleaning the missing data")

        data = self.df
        for column in data.columns:
            if data[column].isnull().sum()>0:
                if data[column].dtype == "float64" or data[column].dtype == "int64":
                    data[column].fillna(data[column].mean(), inplace=True)
                else:
                    data[column].fillna("Unkown", inplace=True)
        
        self.df = data
        messagebox.showinfo("Cleaning done", "Missing Data has been filled")
    
    
    def get_abh_data(self):
        #Function to get abherant data
        
        aberrant_rows = set() 
        total_rows = len(self.df)
        column_aberrant_counts = {column: 0 for column in self.limits.keys()}
        
        for column, limits_range in self.limits.items():
            lower_limit, upper_limit = limits_range
            if isinstance(lower_limit, (int, float)) and isinstance(upper_limit, (int, float)):
                aberrant_indices = self.df[(self.df[column] < lower_limit) | (self.df[column] > upper_limit)].index
                aberrant_rows.update(aberrant_indices)
                column_aberrant_counts[column] = len(aberrant_indices)  # Count aberrant entries for this column
            
            # Check for categorical limits
            elif isinstance(lower_limit, str) and isinstance(upper_limit, str):
                aberrant_indices = self.df[~self.df[column].isin(limits_range)].index
                aberrant_rows.update(aberrant_indices)
                column_aberrant_counts[column] = len(aberrant_indices)
                
                  
        #i want to have percentages of abherant data
        aberrant_rows = list(aberrant_rows)
    
        column_aberrant_percentages = {column: (count / total_rows) * 100 if total_rows > 0 else 0
                                    for column, count in column_aberrant_counts.items()}

        # return self.df.loc[aberrant_rows], column_aberrant_percentages

        result_string = "\n".join(f"{column} : {column_aberrant_percentages[column]:.2f}%" for column in self.limits.keys())
        return result_string 
 
 
    def Random_forrest(self):
        self.df.dropna(inplace=True)
        
        X = self.df.drop('Result', axis=1)  # Features
        y = self.df['Result']
        
        X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)
        rf_classifier = RandomForestClassifier(n_estimators=100, random_state=42)
        rf_classifier.fit(X_train, y_train)
        
        y_pred = rf_classifier.predict(X_test)
        
        return accuracy_score(y_test, y_pred), classification_report(y_test, y_pred), confusion_matrix(y_test, y_pred)
  
  
    def Ada_boost(self):
        self.df.dropna(inplace=True)
        
        X = self.df.drop('Result', axis=1)  # Features
        y = self.df['Result']
        
        
        X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.4, random_state=42)
        
        base_classifier = DecisionTreeClassifier(max_depth=1)
        ada_classifier = AdaBoostClassifier(estimator=base_classifier, n_estimators=50, random_state=42)
        
        ada_classifier.fit(X_train, y_train)
        
        y_pred = ada_classifier.predict(X_test)
        
        return accuracy_score(y_test, y_pred), classification_report(y_test, y_pred), confusion_matrix(y_test, y_pred)
        
        
    def SVM(self):
        self.df.dropna(inplace=True)
        
        X = self.df.drop('Result', axis=1)  # Features
        y = self.df['Result']
        
        
        X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.4, random_state=42)
        
        svm_classifier = SVC(kernel='linear', random_state=42)
        
        svm_classifier.fit(X_train, y_train)
        
        y_pred = svm_classifier.predict(X_test)
        
        return accuracy_score(y_test, y_pred), classification_report(y_test, y_pred), confusion_matrix(y_test, y_pred)
        
        
    def PCA(self):
        pca = PCA(n_components=2)
        X_reduced = pca.fit_transform(self.df[['Age', 'Heart rate', 'Systolic blood pressure', 'Diastolic blood pressure', 'Blood sugar']])
 
        components = pca.components_
        feature_names = ['Age', 'Heart rate', 'Systolic blood pressure', 'Diastolic blood pressure', 'Blood sugar']
        
        
        PC1_label = feature_names[np.argmax(np.abs(components[0]))]
        PC2_label = feature_names[np.argmax(np.abs(components[1]))]
 
        fig, ax = plt.subplots(figsize=(10, 6))
        ax.scatter(X_reduced[:, 0], X_reduced[:, 1], c='blue', alpha=0.5)
        ax.set_title('Principal Component Analysis')
        ax.set_xlabel(PC1_label)
        ax.set_ylabel(PC2_label)
        ax.grid() 
        
        return fig
        
        
    def KMeans(self, kmeans_p:Pipeline = None):
        #Columns : 
        #Age,Gender,Heart rate,Systolic blood pressure,Diastolic blood pressure,Blood sugar,CK-MB,Troponin,Result

        pca = PCA(n_components=2)
        X= pca.fit_transform(self.df[['Age', 'Heart rate', 'Systolic blood pressure', 'Diastolic blood pressure', 'Blood sugar']])
 
        kmeans = KMeans(n_clusters=3, random_state=42)
        self.df['Cluster'] = kmeans.fit_predict(X)
        
        components = pca.components_
        feature_names = ['Age', 'Heart rate', 'Systolic blood pressure', 'Diastolic blood pressure', 'Blood sugar']
        
        
        PC1_label = feature_names[np.argmax(np.abs(components[0]))]
        PC2_label = feature_names[np.argmax(np.abs(components[1]))]
        
        fig, ax = plt.subplots(figsize=(10, 8))
        
        ax.scatter(X[:, 0], X[:, 1], c=self.df['Cluster'], cmap='viridis', alpha=0.5)
        centroids = kmeans.cluster_centers_
        ax.scatter(centroids[:, 0], centroids[:, 1], c='red', marker='X', s=200, label='Centroids')
        
        ax.set_title('KMeans Clustering', fontsize=16)
        ax.set_xlabel(PC1_label)
        ax.set_ylabel(PC2_label)
        ax.legend()
        ax.grid() 
        return fig
        

        
    def Correlation_mx(self):
        self.df.dropna(inplace=True)
        # df_numeric = self.df.select_dtypes(include=[np.number])

        correlation_matrix = self.df.corr()
        fig, ax = plt.subplots(figsize=(10, 8))
        sns.heatmap(correlation_matrix, annot=True, fmt=".2f", cmap='coolwarm', square=True, cbar_kws={"shrink": .8}, ax=ax)
        ax.set_title('Correlation Matrix', fontsize=16)
        
        return fig
        
