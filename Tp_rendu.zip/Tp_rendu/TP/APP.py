#################################################################################################
#                                                                                               #
#                                       DEFINITION                                              #
#                                                                                               #
#################################################################################################
from .DataHandler import DBHandler
from .GUI import GUI
from .Screens import * 
import os 
import tkinter as tk
import pandas as pd

#################################################################################################
#                                                                                               #
#                                           CODE                                                #
#                                                                                               #
#################################################################################################

class APP:
    def __init__(self) -> None:
        
        
        print("Initializing app...")
        self.dbHandler = DBHandler()
        self.GUI = GUI(self.dbHandler)
        self.GUI.run()
        
        
