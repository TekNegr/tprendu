#################################################################################################
#                                                                                               #
#                                       DEFINITION                                              #
#                                                                                               #
#################################################################################################

from .DataHandler import DBHandler
from .Screens import *
import tkinter as tk

#################################################################################################
#                                                                                               #
#                                           CODE                                                #
#                                                                                               #
#################################################################################################

class GUI:
    def __init__(self,dbHandler : DBHandler ):
        print("Loading GUI...")
        self.dbHandler = dbHandler
        self.root = tk.Tk()
        self.root.title("TP")
        self.root.minsize(540, 270)
        self.screen_manager = ScreenManager(self)
        self.screen_manager.show_screen("HomeScreen")
        
    
    def run(self):
        print("running APP...")
        self.root.mainloop()
