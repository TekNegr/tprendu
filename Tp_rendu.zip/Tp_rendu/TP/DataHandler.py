#################################################################################################
#                                                                                               #
#                                       DEFINITION                                              #
#                                                                                               #
#################################################################################################

import os 
import tkinter as tk
import pandas as pd
import numpy as np
from tkinter import ttk, messagebox
from sklearn.model_selection import train_test_split
from sklearn.ensemble import AdaBoostClassifier
from sklearn.tree import DecisionTreeClassifier
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score, classification_report, confusion_matrix
from sklearn.svm import SVC
from sklearn.preprocessing import StandardScaler
from sklearn.cluster import KMeans
import matplotlib.pyplot as plt

#################################################################################################
#                                                                                               #
#                                           CODE                                                #
#                                                                                               #
#################################################################################################

class DBHandler:
    def __init__(self) -> None:
        print("Initializing DBHandler")
        self.filepath = "c:/Users/Pas un taille crayon/Desktop/DevStar/Visu_Donnée_ECE/TP_Rendu/TP/data/Medicaldataset.csv"
        if os.path.exists(self.filepath):
            self.data_status = "Connected"
            self.df = pd.read_csv(self.filepath)
            self.limits = {
            'Age': (0, 120),
            'Gender': (0, 1),
            'Heart rate': (30, 200),
            'Systolic blood pressure': (50, 250),
            'Diastolic blood pressure': (30, 150),
            'Blood sugar': (20, 600),
            'CK-MB': (0, 100),
            'Troponin': (0, 100),
            'Result': ("positive", "negative")
        }
        else : 
            messagebox.showerror("Data absent", "L'Appli ne marche pas sans sa data")
            self.data_status = "Disconnected"
            exit()
            
            
    def get_missing_data(self):
        return self.df.isnull().mean() *100
    
    def clean_abh(self):
 
        for column, limits_range in self.limits.items():
            if column in self.df.columns:
                lower_limit, upper_limit = limits_range
                if isinstance(lower_limit, (int, float)) and isinstance(upper_limit, (int, float)):
                    aberrant_indices = self.df[(self.df[column] < lower_limit) | (self.df[column] > upper_limit)].index 
                    self.df.loc[aberrant_indices, column] = self.df[column].mean()
                
                elif isinstance(lower_limit, str) and isinstance(upper_limit, str):
                    aberrant_indices = self.df[~self.df[column].isin(limits_range)].index
                    self.df.loc[aberrant_indices, column] = self.df[column].mode().iloc[0]
          
    def clean_missing(self):

        data = self.df
        for column in data.columns:
            if data[column].isnull().sum()>0:
                if data[column].dtype == "float64" or data[column].dtype == "int64":
                    data[column].fillna(data[column].mean(), inplace=True)
                else:
                    data[column].fillna("Unkown", inplace=True)
        
        self.df = data
  
    def get_abh_data(self):
        #Function to get abherant data
        
        aberrant_rows = set() 
        total_rows = len(self.df)
        column_aberrant_counts = {column: 0 for column in self.limits.keys()}
        
        for column, limits_range in self.limits.items():
            lower_limit, upper_limit = limits_range
            if isinstance(lower_limit, (int, float)) and isinstance(upper_limit, (int, float)):
                aberrant_indices = self.df[(self.df[column] < lower_limit) | (self.df[column] > upper_limit)].index
                aberrant_rows.update(aberrant_indices)
                column_aberrant_counts[column] = len(aberrant_indices)  # Count aberrant entries for this column
            
            # Check for categorical limits
            elif isinstance(lower_limit, str) and isinstance(upper_limit, str):
                aberrant_indices = self.df[~self.df[column].isin(limits_range)].index
                aberrant_rows.update(aberrant_indices)
                column_aberrant_counts[column] = len(aberrant_indices)
                
                  
        #i want to have percentages of abherant data
        aberrant_rows = list(aberrant_rows)
    
        column_aberrant_percentages = {column: (count / total_rows) * 100 if total_rows > 0 else 0
                                    for column, count in column_aberrant_counts.items()}

        # return self.df.loc[aberrant_rows], column_aberrant_percentages

        result_string = "\n".join(f"{column} : {column_aberrant_percentages[column]:.2f}%" for column in self.limits.keys())
        return result_string 
 
    def Random_forrest(self):
        self.df.dropna(inplace=True)
        
        X = self.df.drop('Result', axis=1)  # Features
        y = self.df['Result']
        
        X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)
        rf_classifier = RandomForestClassifier(n_estimators=100, random_state=42)
        rf_classifier.fit(X_train, y_train)
        
        y_pred = rf_classifier.predict(X_test)
        
        return accuracy_score(y_test, y_pred), classification_report(y_test, y_pred), confusion_matrix(y_test, y_pred)
  
    def Ada_boost(self):
        self.df.dropna(inplace=True)
        
        X = self.df.drop('Result', axis=1)  # Features
        y = self.df['Result']
        
        
        X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.4, random_state=42)
        
        base_classifier = DecisionTreeClassifier(max_depth=1)
        ada_classifier = AdaBoostClassifier(estimator=base_classifier, n_estimators=50, random_state=42)
        
        ada_classifier.fit(X_train, y_train)
        
        y_pred = ada_classifier.predict(X_test)
        
        return accuracy_score(y_test, y_pred), classification_report(y_test, y_pred), confusion_matrix(y_test, y_pred)
        
        
    def SVM(self):
        self.df.dropna(inplace=True)
        
        X = self.df.drop('Result', axis=1)  # Features
        y = self.df['Result']
        
        
        X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.4, random_state=42)
        
        svm_classifier = SVC(kernel='linear', random_state=42)
        
        svm_classifier.fit(X_train, y_train)
        
        y_pred = svm_classifier.predict(X_test)
        
        return accuracy_score(y_test, y_pred), classification_report(y_test, y_pred), confusion_matrix(y_test, y_pred)
        
        
    def KMeans(self):
        
        self.df.dropna(inplace=True)

        scaler = StandardScaler()
        X = scaler.fit_transform(self.df)

        
        k = 3 


        kmeans = KMeans(n_clusters=k, random_state=42)
        kmeans.fit(X)


        labels = kmeans.labels_

        self.df['Cluster'] = labels

        plt.scatter(X[:, 0], X[:, 1], c=labels, cmap='viridis', marker='o')
        plt.scatter(kmeans.cluster_centers_[:, 0], kmeans.cluster_centers_[:, 1], c='red', marker='X', s=200)  # Cluster centers
        plt.title('K-means Clustering')
        plt.xlabel('Feature 1')
        plt.ylabel('Feature 2')
        plt.show()